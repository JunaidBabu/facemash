Project Template
===

This project template needs to be built to be installed.

You will first need to build the Library project in the framework folder, and add the output WPCordovaClassLib.dll file to the CordovaLib folder of this project.

In order to build it in Visual Studio Express for Windows Phone 8 :

1. Open the solution file in Visual Studio
2. Choose File->Export Template and follow the directions.
